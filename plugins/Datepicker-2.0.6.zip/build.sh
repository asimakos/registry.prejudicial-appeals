#!/bin/bash
DATEPICKER_VERSION="2.0.1"
DATEPICKER_ZIP="DatePicker-$DATEPICKER_VERSION.zip"
zip $DATEPICKER_ZIP DatePicker.cfc index.cfm box.json
